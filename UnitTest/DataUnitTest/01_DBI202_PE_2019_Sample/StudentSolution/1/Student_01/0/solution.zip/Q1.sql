select * from EMPLOYEE
where TITLE = 'Head Teller'
